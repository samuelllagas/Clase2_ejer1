import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GeneralExamples extends Base {

    @BeforeTest
    public void initialize() {
        driver = initializeDriver();
    }

    @Test
    public void testGet() throws InterruptedException {
        driver.get("https://www.google.com");
        Thread.sleep(3000);
        driver.get("https://www.instagram.com");
        Thread.sleep(3000);
        driver.get("https://www.twitter.com");
        Thread.sleep(3000);

    }




    @AfterTest
    public void closeDriver() {
        driver.close();
    }
}